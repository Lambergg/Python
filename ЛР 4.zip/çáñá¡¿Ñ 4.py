#Реализовать функцию zip_longest_sum.
lst=[]
lst2=[5,3]

#Функция zip_longest_sum.
def zip_longest_sum(lst,lst2):
    if lst==[] and lst2==[]:
        return []
    elif lst==[] and lst2!=[]:
        return sum(lst2)
    elif lst!=[] and lst2==[]:
        return sum(lst)
    else:
        return sum(lst),sum(lst2)
print(zip_longest_sum(lst,lst2))
