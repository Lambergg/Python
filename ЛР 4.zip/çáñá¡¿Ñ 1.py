#Реализовать функцию is_sorted.
l=list(input('Введите список чисел: '))

#Функция is_sorted.
def is_sorted(l):
    if l==sorted(l):
        return True
    elif l==sorted(l, reverse=True):
        return False

print(is_sorted(l))
