#Реализовать функцию join.
znak=str(input('Введите разделитель: '))
lst=['Khorn','Nurgle','Tzeench','Slaanesh']

#Функция join.
def join(znak,lst):
    if znak=='' and lst==[]:
        return "''"
    else:
        return znak.join(lst)
print(join(znak,lst))
