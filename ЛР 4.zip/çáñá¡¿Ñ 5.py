#Реализовать функцию is_prime.
num=int(input('Введите число: '))

#Функция is_prime.
def is_prime(num):
    for n in range(2, num):
        if num % 2 == 0:
            return False
    return True
print(is_prime(num))
