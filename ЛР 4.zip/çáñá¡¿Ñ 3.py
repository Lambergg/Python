#Реализовать функцию min_max.
lst=[14, 1, 50, 100, -1]

#Функция min_max.
def min_max(lst):
    if lst==[]:
        return (None,None)
    else:
        return min(lst),max(lst)
print(min_max(lst))
