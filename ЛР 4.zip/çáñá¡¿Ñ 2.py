#Реализовать функцию find_longest.
lst=['a','ccc','bbbbbb']

#Функция find_longest.
def find_longest(lst):
    if lst==[]:
        return None
    else:
        return max(lst, key=len)

print(find_longest(lst))
        
