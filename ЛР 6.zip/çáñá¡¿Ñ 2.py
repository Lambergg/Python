#Игра в анаграммы

#Генератор случайных чисел
import random

#Список слов-ответов
answers = ["Отец", "Мама", "Лето", "Весна", "Университет", "Преподаватель", "Python"]

#Переменные
word = random.choice(answers)
right = word
anogramm = ''

#Перемешиваем буквы в слове
while word:
    pos = random.randrange(len(word))
    anogramm += word[pos]
    word = word[:pos] + word[(pos + 1):]

#Начало игры
print('Для выхода из игры нажмите Enter ничего не вводя.')

print('Ваша анограмма: ', anogramm)

answer = input('Введите ваш ответ: ')
answer = answer.capitalize()

#Проверка что было введено правильное слово и не пустая строка
if answer != right and answer != '':
    print('Вы дали неверный ответ. Попробуйте ещё.')
    answer = input('Введите ваш ответ: ')
    answer = answer.capitalize()

#Цикл игры
while answer == right:
    word = random.choice(answers)
    right = word
    anogramm = ''

    while word:
        pos = random.randrange(len(word))
        anogramm += word[pos]
        word = word[:pos] + word[(pos + 1):]

    print('Ваша анограмма: ', anogramm)

    answer = input('Введите ваш ответ: ')
    answer = answer.capitalize()
    if answer != right and answer != '':
        print('Вы дали неверный ответ. Попробуйте ещё.')
        answer = input('Введите ваш ответ: ')
        answer = answer.capitalize()

#Завершение игры
if answer == '':
    print()
    print('Конец игры!')