#Матрица n на m со случайными числами от min до max

import random

#Запрос значений у пользователя
n = int(input('Введите кол-во элементов: '))
m = int(input('Введите кол-во строк: '))
min_value = int(input('Введите минимальное значение: '))
max_value = int(input('Введите максимальное значение: '))
lst = []


#Создаём список
for i in range(m):
    lst.append([0]*n)
    for j in range(n):
        lst[i][j] = random.randint(min_value,max_value)

for i in lst:
    print(i)
                      
                      
