#Приложение лотерея.

import random

ticket = [
    [1,2,3,4,5],
    [6,7,8,9,10],
    [11,12,13,14,15],
    [16,17,18,19,20],
    [21,22,23,24,25],
]

print('Лотерейные билеты:')

for i in ticket:
    print(i)

print(("*")*20)

print('Билет компьютера:')
AI_numbers = []
for j in range(1):
    AI_numbers.append([0]*5)
    for k in range(5):
        AI_numbers[j][k] = ticket[random.randint(0,4)][random.randint(0,4)]

for j in AI_numbers:
    print(j)

print(("*")*20)

print('Билет игрока:')
player_number = []
for a in range(1):
    player_number.append([0]*5)
    for b in range(5):
        player_number[a][b] = ticket[int(input('Введите номер ряда от 0 до 4: '))][int(input('Введите номер числа от 0 до 4: '))]

for a in player_number:
    print(a)

print(("*")*20)

print('Билет компьютера: ',AI_numbers)
print('Билет игрока: ',player_number)