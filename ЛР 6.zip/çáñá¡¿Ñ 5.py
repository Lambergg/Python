#Приложение генерирующее случайный цвет.

import random

red = random.randint(0,255)
green = random.randint(0,255)
blue = random.randint(0,255)

print('red:',red,' green:',green,' blue:',blue)
input('Для шестнадцатиричного формата нажмите Enter')

#Преобразуем наши числа в шестнадцатиричные.
red = hex(red)
green = hex(green)
blue = hex(blue)

print('шестнадцатиричный формат: ',red[2:]+green[2:]+blue[2:])
