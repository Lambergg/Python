#Список из n элементов со случайными числами от min до max

import random

#Запрос значений у пользователя
n = int(input('Введите кол-во элементов: '))
min_value = int(input('Введите минимальное значение: '))
max_value = int(input('Введите максимальное значение: '))

lst = []

#Создаём список
for i in range(0,n+1):
    lst.append(random.randint(min_value,max_value))

print(lst)
