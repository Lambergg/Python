#Матрица заполненная "змейкой".

n = int(input('Введите любое число: '))

lst = [[0]*n]*n
x = 0
y = 0

for i in range(n):
    for j in range(n):
        if i%2 == 0:
            if i==0 and j==0:
                print(0, end=' ')
            elif i!=0 and j==0:
                print(x, end=' ')
            else:
                lst[i][j] = x+1
                print(lst[i][j], end=' ')
                x = lst[i][j]
        else:
            if j==0:
                print(x+n, end=' ')
                y = x + n
                x+=2
            else:
                lst[i][j] = y - 1
                print(lst[i][j], end=' ')
                y -= 1
                x = lst[i][j] + n
    print()
