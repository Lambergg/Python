"""Напишите программу, в которой описана функция, возвращающая ре-
зультатом второе по величине число в списке, переданном функции в ка-
честве аргумента."""

listNum = [1,2,3,4,5,6]

def myfunct(listNum):
    unic_number = list(set(listNum))

    if len(unic_number) < 2:
        return  None
    unic_number.sort(reverse=True)

    return unic_number[1]

result = myfunct(listNum)

if result is not None:
    print(f'Второе по величине число: {result}')
else:
    print("Недостаточно уникальных чисел")