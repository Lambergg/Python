"""Напишите программу, в которой описана функция, возвращающая
результатом сумму нечетных чисел. Количество чисел передается аргу-
ментом функции."""

def sum_of_odds(count):
    total = 0
    for i in range(count):
        number = int(input(f"Введите число {i + 1}: "))
        if number % 2 != 0:
            total += number
    return total

n = int(input("Введите количество чисел: "))
result = sum_of_odds(n)

print("Сумма нечетных чисел:", result)