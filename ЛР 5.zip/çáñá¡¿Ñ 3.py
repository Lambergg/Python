#Бесконечный цикл запрашивает у пользователя ввод числа:
a=[]
count_even=0
count_odd=0
print('Для прерывания цикла введите "end".')
while True:
    n=input('Введите число: ')
    if n=='end':
        break
    else:
        if not n.isdecimal():
            print('Введите целое число!')
        else:
            n=int(n)
            a.append(n)
            if n%2!=0:
                count_odd+=1
            else:
                count_even+=1
print('Чётных: ',count_even, 'Нечётных: ',count_odd)            
            
          
            
