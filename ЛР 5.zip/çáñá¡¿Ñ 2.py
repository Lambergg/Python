#Бесконечный цикл запрашивает у пользователя ввод числа:
a=[]
print('Для прерывания цикла введите "end".')
while True:
    n=input('Введите число: ')
    if n=='end':
        break
    else:
        if not n.isdecimal():
            print('Введите целое число!')
        else:
            n=int(n)
            a.append(n)
print([i for i in a if i%2 !=0])
