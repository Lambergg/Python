#Место Пети в строю по росту.
a=[int(i) for i in input('Введите рост учеников: ').split()]
x=int(input('Введите рост Пети: '))
pos=0

while pos<len(a) and a[pos]>=x:
    pos+=1
print('Позиция Пети в строю: ',pos+1)

