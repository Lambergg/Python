#Поменять местами минимальный и максимальный эелемент списка.
a=[1,5,10,60,8,100]

index_min=0
index_max=0

for i in range(1,len(a)):
    if a[i]>a[index_max]:
        index_max=i
    if a[i]<a[index_min]:
        index_min=i

a[index_min],a[index_max]=a[index_max],a[index_min]
print(a)



