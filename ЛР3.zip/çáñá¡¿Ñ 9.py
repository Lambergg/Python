#Запрос у пользователя email'a.
email=str(input('Введите email: '))

#Определяем Login.
login=email.rsplit('@',1)[0]
print('Login: ', login)

#Отделяем Domain.
domain=email.split('@')[1]
print('Domain: ', domain)
