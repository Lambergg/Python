#Запрос у пользователя Фамилии, Имени и Отчества.
name=str(input('Введите имя: '))
sname=str(input('Введите Фамилию: '))
thname=str(input('Введите отчество: '))

#Вывод фамилии и инициалов с изменением регистра.
c_name = name.capitalize()
c_sname = sname.capitalize()
c_thname = thname.capitalize()
n = c_name[0]
tn = c_thname[0]
print(c_sname, n+'.', tn+'.')
