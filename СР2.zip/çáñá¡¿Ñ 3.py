#Ввод трёх чисел:
num=int(input('Введите первое число: '))
num2=int(input('Введите второе число: '))
num3=int(input('Введите третье число: '))
answer3=3
answer2=2
azero=0
if num==num2==num3:
    print('Все три числа совпадают: ', answer3)
elif num==num2!=num3:
    print('Совпадают числа один и два: ', answer2)
elif num2==num3!=num:
    print('Совпадают числа два и три: ', answer2)
elif num==num3!=num2:
    print('Совпадают числа один и три: ', answer2)
else:
    print('Все числа различны: ', azero)


