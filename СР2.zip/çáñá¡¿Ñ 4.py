#Переменные с двумя целыми числами.
A=1
B=10

for i in range(A,B+1):
    print(i)
