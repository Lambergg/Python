#Написать функцию search_substr.
st=str(input('Введите строку: '))
subst=str(input('Введите подстроку: '))

#Функция search_substr.
def search_substr(subst,st):
    subst=subst.lower()
    st=st.lower()
    if subst in st:
        return 'Есть контакт!'
    else:
        return 'Мимо!'
print(search_substr(subst,st))
