#Четыре действительных числа.
x1=float(input('Введите действительное число х1: '))
y1=float(input('Введите действительное число у1: '))
x2=float(input('Введите действительное число х2: '))
y2=float(input('Введите действительное число у2: '))

#Функция distance.
def distance(x1,y1,x2,y2):
    s1=x1+y1
    s2=x2+y2
    return s1,s2
print(distance(x1,y1,x2,y2))
