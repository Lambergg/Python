#Бесконечный цикл запрашивает у пользователя ввод числа:
while True:
    num=int(input('Введите число: '))
    num2=int(input('Введите число: '))
    stop=str(input('Для прерывания цикла введите end или нажмите Enter что бы продолжить: '))
    res=num+num2
    if stop=="end":
        break
print('Сумма чисел: ', res)
