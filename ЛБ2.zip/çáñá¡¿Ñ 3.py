#Запрос числа у пользователя:
num=int(input('Введите число: '))

#Таблица умножения дляя данного числа:
for i in range(1):
    num2=1
    while num2<=9:
        print(num*num2)
        num2+=1
        
    
    
