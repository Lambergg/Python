#Ввод строки пользователем.
stroka=str(input('Введите любую строку: '))

#Подсчёт кол-ва символов.
count=len(stroka)

#Делим строку на равные части.
res=count//2+count%2

print(stroka[res:]+stroka[:res])
